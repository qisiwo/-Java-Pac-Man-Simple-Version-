package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

public class PacManGame extends JPanel implements ActionListener, KeyListener {

    private static final int TILE_SIZE = 20;
    private static final int BOARD_WIDTH = 20;
    private static final int BOARD_HEIGHT = 15;

    private int pacManX, pacManY;
    private int pacManDirectionX, pacManDirectionY;
    private boolean[][] points;
    private ArrayList<Wall> walls;
    private ArrayList<Ghost> ghosts;
    private ArrayList<Point> powerBeans;

    private Timer timer;
    private int pacManLives;
    private int totalPoints;
    private boolean gameStarted;
    private boolean ghostEnergized;
    private boolean gameOver;
    private boolean gameWon;

    private int score;  // 新增分数
    private enum Direction {
        LEFT, RIGHT, UP, DOWN, NONE;
    }

    private Direction pacManDirection = Direction.NONE;
    private Image PacMan1; // 静止状态的图片
    private Image PacMan2down, PacMan3down,PacMan4down; // 向下移动的两个图片
    private Image PacMan2up, PacMan3up,PacMan4up; // 向上移动的两个图片
    private Image PacMan2left, PacMan3left,PacMan4left; // 向左移动的两个图片
    private Image PacMan2right, PacMan3right,PacMan4right; // 向右移动的两个图片
    private Image FrightFruit,coverImage,gameOverImage;


    private void loadImages() {
        PacMan1 = new ImageIcon(getClass().getResource("/PacManGifs/PacMan1.gif")).getImage();
        PacMan2down = new ImageIcon(getClass().getResource("/PacManGifs/PacMan2down.gif")).getImage();
        PacMan3down = new ImageIcon(getClass().getResource("/PacManGifs/PacMan3down.gif")).getImage();
        PacMan4down = new ImageIcon(getClass().getResource("/PacManGifs/PacMan4down.gif")).getImage();
        PacMan2up = new ImageIcon(getClass().getResource("/PacManGifs/PacMan2up.gif")).getImage();
        PacMan3up = new ImageIcon(getClass().getResource("/PacManGifs/PacMan3up.gif")).getImage();
        PacMan4up = new ImageIcon(getClass().getResource("/PacManGifs/PacMan4up.gif")).getImage();
        PacMan2left = new ImageIcon(getClass().getResource("/PacManGifs/PacMan2left.gif")).getImage();
        PacMan3left = new ImageIcon(getClass().getResource("/PacManGifs/PacMan3left.gif")).getImage();
        PacMan4left = new ImageIcon(getClass().getResource("/PacManGifs/PacMan4left.gif")).getImage();
        PacMan2right = new ImageIcon(getClass().getResource("/PacManGifs/PacMan2right.gif")).getImage();
        PacMan3right = new ImageIcon(getClass().getResource("/PacManGifs/PacMan3right.gif")).getImage();
        PacMan4right = new ImageIcon(getClass().getResource("/PacManGifs/PacMan4right.gif")).getImage();
        FrightFruit = new ImageIcon(getClass().getResource("/PacManGifs/FrightFruit.png")).getImage();
        coverImage = new ImageIcon(getClass().getResource("/PacManGifs/coverImage.jpg")).getImage(); // 封面图像
        gameOverImage = new ImageIcon(getClass().getResource("/PacManGifs/gameoverImage.png")).getImage(); // 结算画面图像
    }
    private void drawWallWithOutline(Graphics g, int x, int y) {
        // 填充墙壁的内部
        g.setColor(Color.BLACK);
        g.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);

        // 设置紫色边框颜色
        g.setColor(new Color(138, 43, 226)); // 紫色

        // 检查相邻墙壁
        boolean leftWall = isWallAt(x - 1, y);
        boolean rightWall = isWallAt(x + 1, y);
        boolean upWall = isWallAt(x, y - 1);
        boolean downWall = isWallAt(x, y + 1);

        // 控制边框的绘制
        // 上边框
        if (!upWall) {
            g.drawLine(x * TILE_SIZE, y * TILE_SIZE,
                    (x + 1) * TILE_SIZE, y * TILE_SIZE);
        }
        // 下边框
        if (!downWall) {
            g.drawLine(x * TILE_SIZE, (y + 1) * TILE_SIZE,
                    (x + 1) * TILE_SIZE, (y + 1) * TILE_SIZE);
        }
        // 左边框
        if (!leftWall) {
            g.drawLine(x * TILE_SIZE, y * TILE_SIZE,
                    x * TILE_SIZE, (y + 1) * TILE_SIZE);
        }
        // 右边框
        if (!rightWall) {
            g.drawLine((x + 1) * TILE_SIZE, y * TILE_SIZE,
                    (x + 1) * TILE_SIZE, (y + 1) * TILE_SIZE);
        }
    }

    // 辅助方法检查是否在指定位置有墙壁
    private boolean isWallAt(int x, int y) {
        for (Wall wall : walls) {
            if (wall.getX() == x && wall.getY() == y) {
                return true;
            }
        }
        return false;
    }


    public PacManGame() {
        pacManLives = 3;
        totalPoints = 0;
        pacManX = 1;
        pacManY = 1;
        pacManDirectionX = 0;
        pacManDirectionY = 0;
        score = 0; // 初始化分数
        gameOver=false;

        points = new boolean[BOARD_HEIGHT][BOARD_WIDTH];
        walls = new ArrayList<>();
        powerBeans = new ArrayList<>();

        for (int i = 0; i < BOARD_HEIGHT; i++) {
            for (int j = 0; j < BOARD_WIDTH; j++) {
                points[i][j] = true;
                totalPoints++;
            }
        }

        setWalls();

        ghosts = new ArrayList<>();
        ghosts.add(new Ghost(10, 10, BOARD_WIDTH, BOARD_HEIGHT,
                "/PacManGifs/Ghost1.gif", "/PacManGifs/GhostScared1.gif"));  // 第一个Ghost的图片
        ghosts.add(new Ghost(15, 5, BOARD_WIDTH, BOARD_HEIGHT,
                "/PacManGifs/Ghost2.gif", "/PacManGifs/GhostScared2.gif"));   // 第二个Ghost的图片

        generatePowerBeans(5);

        setPreferredSize(new Dimension(BOARD_WIDTH * TILE_SIZE,
                BOARD_HEIGHT * TILE_SIZE + 30)); // 增加高度以显示分数
        setBackground(Color.BLACK);

        addKeyListener(this);
        setFocusable(true);

        timer = new Timer(300, this);
        gameStarted = false;

        loadImages();
    }

    private boolean collisionWithWalls(int x, int y) {
        for (Wall wall : walls) {
            if (wall.getX() == x && wall.getY() == y) {
                return true;
            }
        }
        return (x < 0 || x >= BOARD_WIDTH || y < 0 || y >= BOARD_HEIGHT);
    }

    private void setWalls() {
        // 添加边界墙
        for (int i = 0; i < BOARD_WIDTH; i++) {
            walls.add(new Wall(i, 0)); // 上边
            walls.add(new Wall(i, BOARD_HEIGHT - 1)); // 下边
        }
        for (int i = 0; i < BOARD_HEIGHT; i++) {
            walls.add(new Wall(0, i)); // 左边
            walls.add(new Wall(BOARD_WIDTH - 1, i)); // 右边
        }
        //墙壁
        int[][] wallPositions = {
                {2, 1}, {3, 1}, {5, 1}, {6, 1}, {7, 1}, {8, 1},
                {10, 1}, {11, 1}, {12, 1}, {14, 1}, {15, 1}, {16, 1}, {17, 1},

                {1, 3}, {2, 3}, {3, 3}, {5, 3}, {7, 3}, {8, 3}, {10, 3}, {11, 3},
                {12, 3}, {13, 3}, {15, 3}, {16, 3}, {17, 3},

                {1, 5}, {3, 5}, {5, 5}, {7, 5}, {8, 5}, {9, 5}, {10, 5}, {11, 5},
                {13, 5}, {15, 5}, {17, 5},

                {5, 6}, {11, 6},

                {3, 7}, {5, 7}, {12, 7}, {13, 7}, {15, 7}, {17, 7},

                {1, 9}, {3, 9}, {5, 9}, {6, 9}, {7, 9}, {8, 9}, {9, 9}, {10, 9},
                {11, 9}, {12, 9}, {13, 9}, {15, 9}, {17, 9},

                {1, 11}, {2, 11}, {3, 11}, {5, 11}, {6, 11}, {7, 11}, {9, 11},
                {11, 11}, {13, 11}, {15, 11}, {16, 11}, {17, 11},

                {5, 13}, {6, 13},  {13, 13}
        };
        for (int[] pos : wallPositions) {
            walls.add(new Wall(pos[0], pos[1]));
        }
    }
    private void generatePowerBeans(int count) {
        Random rand = new Random();
        while (powerBeans.size() < count) {
            int x = rand.nextInt(BOARD_WIDTH);
            int y = rand.nextInt(BOARD_HEIGHT);
            if (points[y][x] && !collisionWithWalls(x, y)) {
                powerBeans.add(new Point(x, y));
            }
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (!gameStarted) {
            if (key == KeyEvent.VK_S) {
                gameStarted = true;
                timer.start();
            }
        } else if (gameOver) {
            if (key == KeyEvent.VK_Q) {
                System.exit(0); // 退出游戏
            }
        } else {
            switch (key) {
                case KeyEvent.VK_LEFT:
                    pacManDirectionX = -1;
                    pacManDirectionY = 0;
                    pacManDirection = Direction.LEFT;
                    break;
                case KeyEvent.VK_RIGHT:
                    pacManDirectionX = 1;
                    pacManDirectionY = 0;
                    pacManDirection = Direction.RIGHT;
                    break;
                case KeyEvent.VK_UP:
                    pacManDirectionX = 0;
                    pacManDirectionY = -1;
                    pacManDirection = Direction.UP;
                    break;
                case KeyEvent.VK_DOWN:
                    pacManDirectionX = 0;
                    pacManDirectionY = 1;
                    pacManDirection = Direction.DOWN;
                    break;
                default:
                    pacManDirection = Direction.NONE;
                    break;
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameStarted) return;

        int newX = pacManX + pacManDirectionX;
        int newY = pacManY + pacManDirectionY;

        if (!collisionWithWalls(newX, newY)) {
            pacManX = newX;
            pacManY = newY;

            if (points[pacManY][pacManX]) {
                points[pacManY][pacManX] = false;
                totalPoints--;
                score += 10;  // 吃掉豆豆增加分数
            }

            for (Point powerBean : new ArrayList<>(powerBeans)) {
                if (powerBean.x == pacManX && powerBean.y == pacManY) {
                    powerBeans.remove(powerBean);
                    ghostEnergized = true;
                    for (Ghost ghost : ghosts) {
                        ghost.setEnergized(true);
                    }
                    Timer energizeTimer = new Timer(5000, ae -> {
                        ghostEnergized = false;
                        for (Ghost ghost : ghosts) {
                            ghost.setEnergized(false);
                        }
                    });
                    energizeTimer.setRepeats(false);
                    energizeTimer.start();
                    break;
                }
            }
        }
        // 检查是否所有可达的豆子都被吃完
        boolean allPointsEaten = true;
        for (int i = 0; i < BOARD_HEIGHT; i++) {
            for (int j = 0; j < BOARD_WIDTH; j++) {
                if (points[i][j] &&!isWallAt(j, i)) {
                    allPointsEaten = false;
                    break;
                }
            }
            if (!allPointsEaten) break;
        }
        if (allPointsEaten) {
            gameOver = true;
            gameWon=true;
            repaint();
        }

        for (Ghost ghost : ghosts) {
            ghost.move();
            if (ghost.getX() == pacManX && ghost.getY() == pacManY) {
                if (ghost.isEnergized()) {
                    ghost.setPosition(); // 吃掉Ghost，重置位置
                } else {
                    pacManLives--;

                    if (pacManLives <= 0||(allPointsEaten) ) {
                        gameOver = true; // 设置游戏结束状态
                        repaint(); // 刷新界面显示结算画面
                    } else {
                        // 生命数减少，重生Pac-Man
                        pacManX = 1; // 重置位置
                        pacManY = 1;
                        pacManDirection = Direction.NONE; // 重置状态为没有嘴巴
                        pacManDirectionX = 0;
                        pacManDirectionY = 0;
                    }
                }
            }
        }

        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (!gameStarted) {
            // 绘制封面图像
            g.drawImage(coverImage, 0, 0, getWidth(), getHeight(), this);
            g.setColor(Color.RED);
            g.setFont(new Font("Arial", Font.BOLD, 30));
            g.drawString("Press S to Start", BOARD_WIDTH * TILE_SIZE / 4,
                    BOARD_HEIGHT * TILE_SIZE / 2);
        } else {
            // 绘制所有的小点
            for (int i = 0; i < BOARD_HEIGHT; i++) {
                for (int j = 0; j < BOARD_WIDTH; j++) {
                    if (points[i][j]) {
                        g.setColor(Color.YELLOW);
                        // 豆豆更小
                        int smallerBeanSize = TILE_SIZE / 6; // 改小豆豆的尺寸
                        g.fillOval(j * TILE_SIZE + (TILE_SIZE - smallerBeanSize) / 2,
                                i * TILE_SIZE + (TILE_SIZE - smallerBeanSize) / 2,
                                smallerBeanSize, smallerBeanSize);
                    }
                }
            }
            // 绘制生命值
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 14));
            g.drawString("Lives: " + pacManLives, 10, BOARD_HEIGHT * TILE_SIZE + 20);  // 显示生命值
            // 绘制 Pac-Man
            drawPacMan(g);
            // 绘制能量豆
            g.setColor(Color.MAGENTA);
            for (Point powerBean : powerBeans) {
                g.drawImage(FrightFruit, powerBean.x * TILE_SIZE,
                        powerBean.y * TILE_SIZE,TILE_SIZE , TILE_SIZE, this);
            }
            // 绘制 Ghosts
            for (Ghost ghost : ghosts) {
                g.drawImage(ghost.getImage(), ghost.getX() * TILE_SIZE,
                        ghost.getY() * TILE_SIZE, TILE_SIZE, TILE_SIZE, this);
            }

            // 绘制墙壁
            g.setColor(new Color(138, 43, 226)); // 紫色墙壁
            // 绘制墙壁
            for (Wall wall : walls) {
                drawWallWithOutline(g, wall.getX(), wall.getY());
            }

            // 检查游戏是否结束
            if (gameOver) {
                // 显示结算画面
                g.drawImage(gameOverImage, 0, 0, getWidth(), getHeight(), this);

                // 显示分数
                g.setColor(Color.RED);
                g.setFont(new Font("Arial", Font.BOLD, 30));
                g.drawString("Your Score: " + score, BOARD_WIDTH * TILE_SIZE / 4,
                        BOARD_HEIGHT * TILE_SIZE / 2 + 50);
            }
            // 绘制分数
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 14));
            g.drawString("Score: " + score, 10, 20); // 在左上角显示分数 // 显示分数
        }
        if (gameWon) {
            // 显示结算画面
            g.drawImage(gameOverImage, 0, 0, getWidth(), getHeight(), this);
            g.setColor(Color.RED);
            g.setFont(new Font("Arial", Font.BOLD, 30));
            g.drawString("You win!", BOARD_WIDTH * TILE_SIZE / 4, BOARD_HEIGHT * TILE_SIZE / 2);
            g.drawString("Score: " + score, BOARD_WIDTH * TILE_SIZE / 4, BOARD_HEIGHT * TILE_SIZE / 2 + 50);
        }
    }
    private int pacManFrame = 0;  // 用于控制动画的帧
    private long lastTime = 0;    // 用于控制动画的刷新速度

    private void drawPacMan(Graphics g) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastTime > 200) {  // 每150毫秒更新一次帧
            pacManFrame = (pacManFrame + 1) % 4;  // 切换帧 (0到3)
            lastTime = currentTime;
        }

        Image pacManImage = PacMan1;  // 默认使用静止图片

        // 根据方向和帧来选择图片
        switch (pacManDirection) {
            case UP:
                if (pacManFrame == 0) pacManImage = PacMan2up;
                else if (pacManFrame == 1) pacManImage = PacMan3up;
                else if (pacManFrame == 2) pacManImage = PacMan4up;
                break;
            case DOWN:
                if (pacManFrame == 0) pacManImage = PacMan2down;
                else if (pacManFrame == 1) pacManImage = PacMan3down;
                else if (pacManFrame == 2) pacManImage = PacMan4down;
                break;
            case LEFT:
                if (pacManFrame == 0) pacManImage = PacMan2left;
                else if (pacManFrame == 1) pacManImage = PacMan3left;
                else if (pacManFrame == 2) pacManImage = PacMan4left;
                break;
            case RIGHT:
                if (pacManFrame == 0) pacManImage = PacMan2right;
                else if (pacManFrame == 1) pacManImage = PacMan3right;
                else if (pacManFrame == 2) pacManImage = PacMan4right;
                break;
            default:
                pacManImage = PacMan1;  // 如果没有移动，使用静止的图片
                break;
        }

        // 绘制 Pac-Man 图片
        g.drawImage(pacManImage, pacManX * TILE_SIZE,
                pacManY * TILE_SIZE, TILE_SIZE, TILE_SIZE, this);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("PacMan Game");
        PacManGame gamePanel = new PacManGame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(gamePanel);
        frame.pack();
        frame.setVisible(true);
    }
}

