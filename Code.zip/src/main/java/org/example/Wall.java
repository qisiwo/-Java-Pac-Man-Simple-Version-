package org.example;

import java.awt.*;
import java.util.ArrayList;

public class Wall {
    private int x, y;

    public Wall(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public static void drawMergedWalls(Graphics g, ArrayList<Wall> walls,
                                       int boardWidth, int boardHeight, int tileSize) {
        boolean[][] visited = new boolean[boardHeight][boardWidth];

        for (int i = 0; i < boardHeight; i++) {
            for (int j = 0; j < boardWidth; j++) {
                if (!visited[i][j] && isWall(j, i, walls)) {
                    Rectangle boundary = new Rectangle(j, i, 1, 1);
                    findConnectedWalls(j, i, walls, visited, boundary);
                    drawWall(g, boundary, tileSize);
                }
            }
        }
    }

    private static void findConnectedWalls(int x, int y, ArrayList<Wall> walls,
                                           boolean[][] visited, Rectangle boundary) {
        if (x < 0 || x >= visited[0].length || y < 0 || y >= visited.length
                || visited[y][x] || !isWall(x, y, walls)) {
            return;
        }

        visited[y][x] = true;
        boundary.add(x, y);

        findConnectedWalls(x + 1, y, walls, visited, boundary);
        findConnectedWalls(x - 1, y, walls, visited, boundary);
        findConnectedWalls(x, y + 1, walls, visited, boundary);
        findConnectedWalls(x, y - 1, walls, visited, boundary);
    }

    private static boolean isWall(int x, int y, ArrayList<Wall> walls) {
        for (Wall wall : walls) {
            if (wall.getX() == x && wall.getY() == y) {
                return true;
            }
        }
        return false;
    }

    private static void drawWall(Graphics g, Rectangle boundary, int tileSize) {
        // 画紫色边框
        g.setColor(new Color(138, 43, 226));
        g.drawRect(boundary.x * tileSize, boundary.y * tileSize,
                boundary.width * tileSize, boundary.height * tileSize);

        // 画黑色内部
        g.setColor(Color.BLACK);
        g.fillRect(boundary.x * tileSize, boundary.y * tileSize,
                boundary.width * tileSize, boundary.height * tileSize);
    }
}
