package org.example;

import javax.swing.*;
import java.util.Random;
import java.awt.Image;

public class Ghost {
    private int x, y;  // Ghost的位置
    private boolean energized; // Ghost 是否被能量豆影响
    private Random rand;
    private int boardWidth; // 游戏区域宽度
    private int boardHeight; // 游戏区域高度
    private Image ghostImage; // 普通状态 Ghost 图片
    private Image ghostEnergizedImage; // 被能量豆影响时的图片

    public Ghost(int startX, int startY, int boardWidth, int boardHeight,
                 String imagePath, String energizedImagePath) {
        this.x = startX;
        this.y = startY;
        this.energized = false; // 初始状态为普通状态
        this.rand = new Random();
        this.boardWidth = boardWidth;
        this.boardHeight = boardHeight;

        // 加载图片
        this.ghostImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
        this.ghostEnergizedImage = new ImageIcon(getClass().getResource(energizedImagePath)).getImage();

    }

    public void move() {
        // 随机选择一个方向移动
        int direction = rand.nextInt(4);  // 0=上, 1=下, 2=左, 3=右
        switch (direction) {
            case 0: if (y > 0) y--; break;  // 向上
            case 1: if (y < boardHeight - 1) y++; break;  // 向下
            case 2: if (x > 0) x--; break;  // 向左
            case 3: if (x < boardWidth - 1) x++; break;  // 向右
        }
    }

    public void setEnergized(boolean energized) {
        this.energized = energized;
    }

    public boolean isEnergized() {
        return energized;
    }

    public void setPosition() {
        this.x = 1; // 重新设置Ghost的位置
        this.y = 1; // 可以根据需要选择在其他位置
    }

    public int getX() { return x; }
    public int getY() { return y; }

    public Image getImage() {
        return energized ? ghostEnergizedImage : ghostImage; // 根据状态返回对应图片
    }
}

